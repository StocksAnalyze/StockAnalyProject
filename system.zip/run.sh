#!/bin/bash

python3 GetAnaly.py
python3 GetProb.py