#!/bin/bash

echo "start Install"

sudo apt-get update
sudo apt-get upgrade
sudo apt-get install g++ gcc make gnu git-all

if which python3 > /dev/null 2>&1; then
    echo "Python이 설치되어 있습니다."
else
    echo "Python이 설치되어 있지 않습니다."
    sudo apt install python3
fi
sudo apt install python3-pip

file="ta-lib-0.4.0-src.tar.gz"
marcap_file="marcap"

# ta-lib 파일 있는지 확인
if [ -e "$file" ]; then
    echo "pre-installd ta-lib file!"
else
    echo "install ta-lib"
    sudo apt update
    sudo apt install build-essential wget -y

    wget https://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
    tar -xzf ta-lib-0.4.0-src.tar.gz
    cd ta-lib

    ./configure -prefix=/usr
    make

    sudo make install
    pip3 install ta-lib
fi 

module=("pykrx" "pandas" "pymongo" "matplotlib")
for val in "${module[@]}"; do
    if python3 -c "import $val" &> /dev/null; then
        echo "$val is installed"
    else
        echo "$val install start"
        pip3 install $val
    fi
done

'''
echo "marcap Install"
if [ -e "$marcap_file" ]; then
    echo "pre-install marcap file!"
else
    git clone "https://github.com/FinanceData/marcap.git" marcap
fi
'''

echo "finish"